# 코멘토 2차 - GoogleTest/gMock 실행 최종 점검

검증 날짜: 2026-10-31 / 실행 환경: Debian 13, GCC 14.2, Clang, Python 3.13.5, OpenCV(Python) 4.13.0

## 실제 실행 결과

| 항목 | 명령 / 검증 | 결과 |
|---|---|---|
| Python 단위 테스트 | `python -m unittest discover -s . -p 'test*.py' -v` | **67/67 PASS** |
| Python 커버리지 | `python -m pytest week2/test_image_to_3d.py -q --cov=week2.image_to_3d --cov-report=term-missing` | **38 PASS + 39 subtests, 99%** |
| C++ 독립 검사 | `cmake -S week2/cpp -B build/cpp-offline -DCOMENTO_ENABLE_GOOGLETEST=OFF`, 빌드, CTest | **16/16 PASS**, CTest 1/1 PASS |
| C++ Clang | `clang++ -std=c++17 -O2 -Wall -Wextra -Wconversion -Werror ...` | 컴파일 PASS, 16/16 PASS |
| GCC ASan/UBSan | `-fsanitize=address,undefined` 빌드와 실행 | **16/16 PASS** (GoogleTest 아님) |
| Python↔C++ 좌표 비교 | 고정 난수 시드, 150개 합성 입력 | **150/150 PASS** (atol 3e-6) |
| Git 무결성 | `git fsck --full --no-reflogs --strict` | **PASS** |
| **GoogleTest/gMock 21개** | `cmake ... -DCOMENTO_ENABLE_GOOGLETEST=ON` | **CONFIGURE FAIL / 0 RUN**: C++ OpenCV 개발 헤더와 GoogleTest/gMock 라이브러리 미설치 |
| C++ OpenCV 어댑터 | 실제 빌드 | **NOT RUN**: `libopencv-dev` 없음 |
| GitHub Actions CI | 원격 실행 | **NOT RUN**: 사용자 검토 전 Push하지 않음 |

### 중요

- GoogleTest/gMock 21개는 **테스트 소스 코드에 정의된 개수**이며 실제 PASS 개수가 아닙니다.
- C++ 독립 검사 16개는 GoogleTest가 아닙니다.
- `COMENTO_ENABLE_GOOGLETEST=ON` 상태에서 OpenCV가 없으면 이제 CMake가 명시적으로 실패합니다. 시험 대상이 조용히 제외되는 문제를 방지합니다.
- 이 환경에서는 외부 패키지 다운로드/설치가 되지 않아 실제 GoogleTest 바이너리를 생성하지 못했습니다.
- 1차 PR #1의 macOS 이미지 픽셀 일치 실패 기록은 이번 Debian 환경의 PASS 결과로 해결됐다고 판단할 수 없습니다.

## 전체 GoogleTest/gMock을 실제 실행하는 명령 (Ubuntu 24.04 또는 GitHub Actions)

```bash
sudo apt-get update
sudo apt-get install -y g++ cmake libopencv-dev libgtest-dev libgmock-dev
cmake -S week2/cpp -B build/cpp -DCOMENTO_ENABLE_GOOGLETEST=ON
cmake --build build/cpp --parallel 2
ctest --test-dir build/cpp --output-on-failure
./build/cpp/cpp_depth_demo data/originals/sample_02.jpg build/cpp/depth_cpp.png
```

위 명령이 통과하고 CI에서 실제 로그가 확인되기 전에는 GoogleTest/gMock 요구사항을 최종 PASS로 평가하지 않습니다.
