# 원격 Push 및 2주차 PR 검토 계획

## 승인 대상

| 항목 | 준비한 값 |
|---|---|
| 저장소 | https://github.com/brightlcy/comento-image-processing |
| 새 원격 브랜치 | `feature/week2-final-execution-20261031` |
| 2주차 PR base | `feature/image-processing` |
| 보존한 원격 1주차 커밋 | `ea19e846bad43211246eb854349bbcbc80292b95` |
| 원격 main | `5e5f651be12ae47057d0454caa53f2e27012ee50` — 변경하지 않았습니다. |
| 현재 1주차 PR | https://github.com/brightlcy/comento-image-processing/pull/1 — 열린 상태이며 수정·병합하지 않았습니다. |
| CI | 실제 실행 0회, 두 Job NOT RUN, 실행 URL 없음 |

먼저 PR 설명을 검토받습니다. 설명이 승인되면 새 브랜치를 Push하고 두 Job을 확인한 뒤 2주차 PR을 생성할 예정입니다. main Push, 강제 Push, 기존 PR 병합은 포함하지 않습니다. 사용자가 승인하기 전에는 원격에 기록하지 않습니다.

## 변경 범위

- 첨부 ZIP에 이미 있던 `week2/`의 Python·C++·결과 PNG·4장 PPT 이력을 보존하였습니다.
- 원격 1주차 브랜치의 추가 커밋 2개를 로컬 병합하였습니다. README 충돌은 최신 1주차 검증 기록과 2주차 안내를 함께 보존하는 방향으로 해결하였습니다.
- `.github/workflows/comento-week2-cpp.yml`: 기존 두 Job을 유지하고 원문 로그·XML·항상 업로드·명시적 Bash pipefail·sanitizer·언어 간 비교를 추가하였습니다.
- `week2/cpp/CMakeLists.txt`: gMock 플래그 초기화와 테스트용 XYZ 비교 실행 파일 연결을 추가하였습니다.
- C++ 테스트 2개 파일: 기존 기대값을 유지하고 경계 검증 10개를 추가하였습니다.
- `week2/cpp/tests/xyz_probe.cpp`, `week2/tools/`: 테스트용 언어 간 비교·임시 변이 검증 도구입니다.
- README·PR 설명·검증 기록·4장 PPT를 실제 실행 결과에 맞추었습니다.
- `.gitignore`에 `build/`를 추가하였습니다. 기존 Python 생산 코드·이미지·멘토 실험 결과는 바이트 단위로 보존하였습니다.
- `week1_report.pptx`는 첨부 ZIP에 있던 이전 파일을 그대로 보존한 것입니다. 원격의 `1week.ppt`도 함께 보존하였습니다. 1주차 발표 자료를 새로 수정하지 않았습니다.

정확한 전체 변경 파일과 최종 커밋 목록은 제출 ZIP의 `HANDOFF/Git_Approval_Plan.md` 및 `HANDOFF/git_handoff.json`에서 확인할 수 있습니다. GitHub에 올리기 전에는 아래 명령으로 원격이 추가 변경되지 않았는지 확인해야 합니다.

```bash
git fetch origin
git status --short --branch
git log --oneline origin/feature/image-processing..HEAD
git diff --stat origin/feature/image-processing...HEAD
git merge-base --is-ancestor origin/feature/image-processing HEAD
```

## 승인 후 순서

1. 사용자가 PR 설명과 최종 PPT를 검토하고 위 브랜치의 원격 반영을 승인합니다.
2. 원격을 다시 조회하고 승인한 커밋만 새 브랜치에 Push합니다.
3. [Actions 화면](https://github.com/brightlcy/comento-image-processing/actions)에서 해당 브랜치·커밋의 `Comento Week 2 C++ GoogleTest and Python` 실행을 엽니다.
4. `cpp-google-test`와 `python-regression`의 실제 상태를 확인합니다. `week2-cpp-evidence`와 `week2-python-evidence` 아티팩트에서 로그·XML·버전을 검토합니다.
5. 실패하면 원문 원인을 분리하여 처리하고 다시 실행합니다. CI 성공 전에는 CI PASS로 보고하지 않습니다.
6. 두 Job이 통과하면 실제 Run URL과 결과를 반영하고 새 2주차 PR을 생성합니다.
7. 사용자가 Files changed·Checks·PPT를 확인하고 멘토 리뷰를 진행합니다. 병합은 별도의 사용자 승인 후 진행합니다.

승인 후 사용할 Push 명령은 다음과 같습니다. 아직 실행하지 않았습니다.

```bash
git push -u origin HEAD:feature/week2-final-execution-20261031
```

1주차 PR이 먼저 병합되면 새 2주차 PR의 base를 main으로 바꾸기 전에 변경 범위와 원격 이력을 다시 확인합니다.

## 이번 최종 수정

사용자가 수정한 `week2/comento_week2.ppt`로 발표 자료를 교체했습니다. 이전 `week2/week2_report.pptx`는 현재 제출 목록에서 제외하고 Git 이력에 보존했습니다. PR 설명은 `week2/PR_DESCRIPTION.md`에서 먼저 검토받고 있으며, 아직 Push와 새 PR 생성을 진행하지 않았습니다. 기존 PR #1의 리뷰·일반 댓글·코드 리뷰 댓글은 모두 0건으로 확인했습니다.
